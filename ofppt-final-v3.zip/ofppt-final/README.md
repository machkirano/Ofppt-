# OFPPT Smart Assistant v3.0
## 100% Free · Production-Ready · PWA

---

## ✅ Free Stack

| Layer | Technology | Cost |
|-------|-----------|------|
| Frontend | React + Vite + TypeScript | Free |
| Styling | TailwindCSS + Framer Motion | Free |
| State | Zustand (no backend needed) | Free |
| AI Chat | Gemini 1.5 Flash (15 req/min free) | Free |
| Speech-to-Text | Web Speech API (browser built-in) | Free |
| Text-to-Speech | Web Speech API (browser built-in) | Free |
| OCR | Tesseract.js (browser, add when needed) | Free |
| PWA | vite-plugin-pwa + Workbox | Free |
| Hosting | Cloudflare Pages / Vercel / Netlify | Free |
| Backend | Render.com free tier | Free |
| Database | Supabase free tier / PostgreSQL | Free |

---

## 🗂 Project Structure

```
frontend/
├── src/
│   ├── ai/
│   │   └── ai.service.ts       # Free AI: Gemini + Web Speech + local fallback
│   ├── components/
│   │   ├── feedback/
│   │   │   └── ErrorBoundaries.tsx  # Global + Route + API error boundaries
│   │   ├── layout/
│   │   │   └── AppLayout.tsx   # Header + Sidebar + BottomNav (mobile)
│   │   └── ui/
│   │       └── Toast.tsx       # Toast notification system
│   ├── hooks/
│   │   └── (useDebounce, useThrottle, useLazyVisible, useIdle...)
│   ├── pages/
│   │   ├── ChatPage.tsx        # Main AI chat (lazy loaded)
│   │   └── SettingsPage.tsx    # Settings + all other page stubs
│   ├── pwa/
│   │   └── PWAManager.tsx      # Install banner, update banner, offline indicator
│   ├── router/
│   │   └── index.tsx           # Lazy routes + prefetching + error boundaries
│   ├── store/
│   │   └── index.ts            # Zustand: UI + AI + Chat + Gamification
│   ├── styles/
│   │   └── globals.css         # Tailwind + custom utilities
│   └── utils/
│       └── vitals.ts           # Web Vitals + performance hooks + cn()
├── .github/workflows/
│   ├── ci.yml                  # Lint + TypeCheck + Test + Build
│   └── deploy.yml              # Deploy to Cloudflare Pages (free)
├── index.html                  # Critical CSS + loading screen
├── vite.config.ts              # PWA + code splitting + Workbox
└── tailwind.config.ts          # Design system tokens
```

---

## 🚀 Quick Start

```bash
cd frontend
npm install
cp .env.example .env.local
# Add your FREE Gemini key: https://aistudio.google.com/app/apikey

npm run dev        # → http://localhost:5173
npm run build      # Production build
npm run typecheck  # TypeScript check
npm run lint       # ESLint
npm test           # Vitest unit tests
```

---

## 📊 Bundle Budget

| Chunk | Size (gzipped) | Load |
|-------|---------------|------|
| vendor-react | ~35KB | Always |
| vendor-router | ~8KB | Always |
| vendor-state | ~12KB | Always |
| **Total initial** | **~55KB** | **Always** |
| vendor-motion | ~50KB | Lazy |
| vendor-icons | ~18KB | Lazy |
| chunk-mermaid | ~180KB | Mindmap only |
| page-* | ~5-15KB each | On navigate |

---

## 🎯 Lighthouse Targets

```
Performance:    95+   (critical CSS inline, lazy routes, Workbox cache)
Accessibility:  95+   (RTL, aria labels, semantic HTML)
Best Practices: 95+   (HTTPS, CSP, no console errors)
SEO:            90+   (meta tags, manifest, sitemap)
PWA:            ✅    (installable, offline-ready, push notifications)
```

---

## 🔑 Get Free Gemini API Key

1. Go to: https://aistudio.google.com/app/apikey
2. Sign in with Google (free)
3. Create API key
4. Add in Settings page OR `.env.local` as `VITE_GEMINI_KEY`

**Free limits:** 15 requests/minute · 1M tokens/day · No credit card needed

---

## 🌐 Free Deployment

### Option A — Cloudflare Pages (Recommended)
```bash
# 1. Push to GitHub
# 2. Connect repo at dash.cloudflare.com/pages
# 3. Build command: npm run build
# 4. Output dir: dist
# Free: unlimited bandwidth, 500 builds/month, custom domain
```

### Option B — Vercel
```bash
npm i -g vercel
vercel --prod
# Free: 100GB bandwidth, unlimited deploys
```

### Option C — Netlify
```bash
npm i -g netlify-cli
netlify deploy --prod --dir=dist
# Free: 100GB bandwidth, 300 build minutes/month
```

---

## 🔄 CI/CD (GitHub Actions — Free)

Workflows included:
- `ci.yml` → runs on every PR: lint + typecheck + test + build verification
- `deploy.yml` → runs on push to main: auto-deploy to Cloudflare Pages

**Cost: $0** — GitHub Actions free tier: 2,000 min/month for public repos (unlimited)

---

## ⚡ Performance Optimizations Applied

1. **Route-based code splitting** — each page is a separate chunk
2. **Workbox caching** — API 5min, AI 10min, fonts 1year
3. **Critical CSS inline** — no render-blocking CSS
4. **Web Speech API** — zero cost STT/TTS, no Whisper API needed
5. **5-minute AI cache** — userId+hash key, auto-eviction at 100 entries
6. **Virtual scroll ready** — `useLazyVisible` for long lists
7. **requestIdleCallback** — deferred prefetching
8. **Reduced motion** — respects OS accessibility setting
9. **Background sync** — queues messages when offline via IndexedDB
10. **Error boundaries** — 3 levels prevent full app crashes
