import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'
import { visualizer } from 'rollup-plugin-visualizer'
import path from 'path'

export default defineConfig(({ mode }) => ({
  plugins: [
    react(),

    // ── PWA: vite-plugin-pwa + Workbox ─────────────────────
    VitePWA({
      registerType:    'prompt',         // prompt user before update
      injectRegister: 'script-defer',
      devOptions:      { enabled: true },

      manifest: {
        name:             'OFPPT Smart Assistant',
        short_name:       'OFPPT AI',
        description:      'مساعد ذكي لطلاب OFPPT — هندسة كهربائية وطاقة',
        start_url:        '/?pwa=1',
        scope:            '/',
        display:          'standalone',
        background_color: '#060A12',
        theme_color:      '#060A12',
        dir:              'rtl',
        lang:             'ar-MA',
        orientation:      'portrait-primary',
        icons: [
          { src: '/icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: '/icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' },
        ],
        shortcuts: [
          { name: 'الشات',    url: '/chat',       icons: [{ src: '/icons/icon-96.png', sizes: '96x96' }] },
          { name: 'المحاكي', url: '/simulator',   icons: [{ src: '/icons/icon-96.png', sizes: '96x96' }] },
        ],
        categories: ['education', 'productivity'],
      },

      // ── Workbox config ────────────────────────────────────
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,woff2}'],
        cleanupOutdatedCaches: true,
        skipWaiting: false,          // wait for user to update
        clientsClaim: true,

        runtimeCaching: [
          // Google Fonts — cache forever
          {
            urlPattern: /^https:\/\/fonts\.(googleapis|gstatic)\.com\/.*/i,
            handler:    'CacheFirst',
            options: {
              cacheName: 'google-fonts',
              expiration: { maxAgeSeconds: 60 * 60 * 24 * 365, maxEntries: 30 },
              cacheableResponse: { statuses: [0, 200] },
            },
          },
          // Static images
          {
            urlPattern: /\.(?:png|jpg|jpeg|svg|gif|webp|avif)$/i,
            handler:    'CacheFirst',
            options: {
              cacheName: 'images',
              expiration: { maxAgeSeconds: 60 * 60 * 24 * 30, maxEntries: 100 },
            },
          },
          // API GET requests — Network First with 5min cache
          {
            urlPattern: ({ url, request }: any) =>
              url.pathname.startsWith('/api/') && request.method === 'GET',
            handler: 'NetworkFirst',
            options: {
              cacheName: 'api-cache',
              networkTimeoutSeconds: 10,
              expiration: { maxAgeSeconds: 60 * 5, maxEntries: 50 },
              cacheableResponse: { statuses: [200] },
            },
          },
          // AI responses — Stale-While-Revalidate 10 min
          {
            urlPattern: ({ url }: any) => url.pathname.includes('/ai/') || url.pathname.includes('/chat/'),
            handler:    'StaleWhileRevalidate',
            options: {
              cacheName: 'ai-responses',
              expiration: { maxAgeSeconds: 60 * 10, maxEntries: 30 },
              cacheableResponse: { statuses: [200] },
            },
          },
        ],
      },
    }),

    // Bundle visualizer (only when ANALYZE=true)
    mode === 'analyze' && visualizer({
      open:     true,
      filename: 'dist/bundle-report.html',
      gzipSize: true,
    }),
  ].filter(Boolean),

  resolve: {
    alias: {
      '@':           path.resolve(__dirname, './src'),
      '@components': path.resolve(__dirname, './src/components'),
      '@pages':      path.resolve(__dirname, './src/pages'),
      '@hooks':      path.resolve(__dirname, './src/hooks'),
      '@store':      path.resolve(__dirname, './src/store'),
      '@services':   path.resolve(__dirname, './src/services'),
      '@utils':      path.resolve(__dirname, './src/utils'),
      '@ai':         path.resolve(__dirname, './src/ai'),
      '@pwa':        path.resolve(__dirname, './src/pwa'),
    },
  },

  build: {
    target:    'es2020',
    sourcemap:  mode !== 'production',
    minify:    'terser',
    terserOptions: {
      compress: {
        drop_console:  mode === 'production',
        drop_debugger: true,
        passes:        2,
      },
    },
    rollupOptions: {
      output: {
        manualChunks: (id) => {
          // Core framework — always load
          if (id.includes('/react/') || id.includes('/react-dom/'))      return 'vendor-react'
          if (id.includes('react-router'))                                return 'vendor-router'
          if (id.includes('zustand') || id.includes('react-query'))      return 'vendor-state'
          // Heavy — lazy only
          if (id.includes('framer-motion'))                              return 'vendor-motion'
          if (id.includes('lucide-react'))                               return 'vendor-icons'
          if (id.includes('mermaid'))                                    return 'chunk-mermaid'
          // Feature pages
          if (id.includes('/pages/Chat'))                                return 'page-chat'
          if (id.includes('/pages/Simulator'))                           return 'page-simulator'
          if (id.includes('/pages/Flashcards'))                          return 'page-flashcards'
          if (id.includes('/pages/Mindmap'))                             return 'page-mindmap'
          if (id.includes('/pages/Quiz'))                                return 'page-quiz'
          if (id.includes('/ai/'))                                       return 'chunk-ai'
          if (id.includes('node_modules'))                               return 'vendor-misc'
        },
      },
    },
    chunkSizeWarningLimit: 500,
    assetsInlineLimit:     4096,
  },

  server: {
    port:  5173,
    proxy: {
      '/api': { target: 'http://localhost:3001', changeOrigin: true },
    },
  },

  test: {
    globals:     true,
    environment: 'jsdom',
    setupFiles:  ['./src/utils/test-setup.ts'],
    coverage:    { provider: 'v8', reporter: ['text', 'html'] },
  },
}))
