// ══════════════════════════════════════════════════════════
// src/utils/vitals.ts — Free Web Vitals monitoring
// ══════════════════════════════════════════════════════════

export async function reportWebVitals() {
  try {
    const { onCLS, onFCP, onINP, onLCP, onTTFB } = await import('web-vitals')

    const report = (metric: any) => {
      if (import.meta.env.DEV) {
        const color = metric.rating === 'good' ? '✅' : metric.rating === 'needs-improvement' ? '⚠️' : '❌'
        console.log(`[Vitals] ${color} ${metric.name}: ${Math.round(metric.value)}${metric.name === 'CLS' ? '' : 'ms'} (${metric.rating})`)
      }
      // Free analytics: use navigator.sendBeacon to avoid blocking
      if ('sendBeacon' in navigator && import.meta.env.PROD) {
        navigator.sendBeacon('/api/v1/analytics/vitals', JSON.stringify({
          name: metric.name, value: metric.value, rating: metric.rating, id: metric.id,
        }))
      }
    }

    onCLS(report); onFCP(report); onINP(report); onLCP(report); onTTFB(report)
  } catch { /* web-vitals not available */ }
}

// ══════════════════════════════════════════════════════════
// src/hooks/usePerformance.ts — Optimized React hooks
// ══════════════════════════════════════════════════════════
import { useRef, useEffect, useState, useCallback } from 'react'

// Debounce
export function useDebounce<T>(value: T, ms: number): T {
  const [v, setV] = useState(value)
  useEffect(() => { const t = setTimeout(() => setV(value), ms); return () => clearTimeout(t) }, [value, ms])
  return v
}

// Throttle
export function useThrottle<T extends (...args: any[]) => any>(fn: T, ms: number): T {
  const last  = useRef(0)
  return useCallback((...args: Parameters<T>) => {
    const now = Date.now()
    if (now - last.current >= ms) { last.current = now; return fn(...args) }
  }, [fn, ms]) as T
}

// Intersection observer for lazy rendering
export function useLazyVisible(threshold = 0.1): [React.RefObject<HTMLDivElement>, boolean] {
  const ref      = useRef<HTMLDivElement>(null)
  const [vis, setVis] = useState(false)
  useEffect(() => {
    if (!ref.current) return
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setVis(true); obs.disconnect() } }, { threshold, rootMargin: '60px' })
    obs.observe(ref.current)
    return () => obs.disconnect()
  }, [threshold])
  return [ref, vis]
}

// Idle callback (defer non-urgent work)
export function useIdle(fn: () => void, deps: React.DependencyList = []) {
  useEffect(() => {
    if ('requestIdleCallback' in window) {
      const id = requestIdleCallback(fn, { timeout: 2000 })
      return () => cancelIdleCallback(id)
    }
    const t = setTimeout(fn, 300)
    return () => clearTimeout(t)
  }, deps) // eslint-disable-line
}

// Reduced motion
export function useReducedMotion(): boolean {
  const [v, setV] = useState(() => window.matchMedia('(prefers-reduced-motion: reduce)').matches)
  useEffect(() => {
    const mq  = window.matchMedia('(prefers-reduced-motion: reduce)')
    const fn  = (e: MediaQueryListEvent) => setV(e.matches)
    mq.addEventListener('change', fn)
    return () => mq.removeEventListener('change', fn)
  }, [])
  return v
}

// Network quality detection
export function useNetwork() {
  const conn = (navigator as any).connection
  const [slow, setSlow] = useState(
    conn?.effectiveType === '2g' || conn?.effectiveType === 'slow-2g' || conn?.saveData
  )
  useEffect(() => {
    const update = () => {
      const c = (navigator as any).connection
      setSlow(c?.effectiveType === '2g' || c?.effectiveType === 'slow-2g' || c?.saveData)
    }
    conn?.addEventListener('change', update)
    return () => conn?.removeEventListener('change', update)
  }, [conn])
  return { slow, online: navigator.onLine }
}

// Scroll restoration
export function useScrollRestore(key: string) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const el  = ref.current
    if (!el) return
    const pos = sessionStorage.getItem(`scroll:${key}`)
    if (pos) el.scrollTop = parseInt(pos, 10)
    return () => { if (el) sessionStorage.setItem(`scroll:${key}`, String(el.scrollTop)) }
  }, [key])
  return ref
}

// Memoized class name helper
import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
export const cn = (...i: ClassValue[]) => twMerge(clsx(i))

// test setup
export {}
