import { useState, useEffect, useCallback } from 'react'
import { useRegisterSW } from 'virtual:pwa-register/react'
import { motion, AnimatePresence } from 'framer-motion'
import { cn } from '@utils/vitals'

// ═══════════════════════════════════════════════════════════
// PWA Manager — vite-plugin-pwa + Workbox integration
// 100% free — no paid push service
// ═══════════════════════════════════════════════════════════

// ── SW Registration with auto-update check ─────────────────
export function usePWAUpdate() {
  const { needRefresh, updateServiceWorker } = useRegisterSW({
    onRegistered:  (r) => console.log('[PWA] SW registered', r?.scope),
    onRegisterError:(e) => console.warn('[PWA] SW error', e),
    onOfflineReady: ()  => console.log('[PWA] Ready for offline'),
  })

  return {
    updateAvailable: needRefresh[0],
    applyUpdate:     () => updateServiceWorker(true),
  }
}

// ── Install prompt ─────────────────────────────────────────
export function usePWAInstall() {
  const [deferredPrompt, setDeferred] = useState<any>(null)
  const [isInstallable,  setInstallable] = useState(false)
  const [isInstalled,    setInstalled]   = useState(
    () => window.matchMedia('(display-mode: standalone)').matches
  )

  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault()
      setDeferred(e)
      setInstallable(true)
    }
    const onInstalled = () => {
      setInstalled(true)
      setInstallable(false)
      setDeferred(null)
    }
    window.addEventListener('beforeinstallprompt', onPrompt)
    window.addEventListener('appinstalled',         onInstalled)
    return () => {
      window.removeEventListener('beforeinstallprompt', onPrompt)
      window.removeEventListener('appinstalled',         onInstalled)
    }
  }, [])

  const install = useCallback(async (): Promise<boolean> => {
    if (!deferredPrompt) return false
    deferredPrompt.prompt()
    const { outcome } = await deferredPrompt.userChoice
    setDeferred(null)
    setInstallable(false)
    return outcome === 'accepted'
  }, [deferredPrompt])

  return { isInstallable, isInstalled, install }
}

// ── Online status ──────────────────────────────────────────
export function useOnlineStatus() {
  const [online, setOnline] = useState(navigator.onLine)
  useEffect(() => {
    const on  = () => setOnline(true)
    const off = () => setOnline(false)
    window.addEventListener('online',  on)
    window.addEventListener('offline', off)
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off) }
  }, [])
  return online
}

// ── Queue message for background sync (IndexedDB) ─────────
export async function queueOfflineMessage(chatId: string, content: string): Promise<void> {
  try {
    const { openDB } = await import('idb')
    const db = await openDB('ofppt-sync', 1, {
      upgrade: (db) => db.createObjectStore('messages', { keyPath: 'id', autoIncrement: true }),
    })
    await db.add('messages', { chatId, content, timestamp: Date.now() })
    await (navigator as any).serviceWorker?.ready?.then((r: any) =>
      r.sync?.register('sync-messages').catch(() => {})
    )
  } catch { /* ignore if idb not available */ }
}

// ── Update Banner Component ────────────────────────────────
export function PWAUpdateBanner() {
  const { updateAvailable, applyUpdate } = usePWAUpdate()

  return (
    <AnimatePresence>
      {updateAvailable && (
        <motion.div
          initial={{ y: -60, opacity: 0 }}
          animate={{ y: 0,   opacity: 1 }}
          exit={{    y: -60, opacity: 0 }}
          className="fixed top-0 inset-x-0 z-[9999] bg-primary text-white py-2.5 px-4 flex items-center justify-center gap-3 text-sm font-medium"
        >
          <span>✨ تحديث جديد متاح</span>
          <button
            onClick={applyUpdate}
            className="underline font-bold hover:no-underline transition-all"
          >
            تطبيق الآن
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

// ── Install Banner Component ───────────────────────────────
export function PWAInstallBanner() {
  const { isInstallable, isInstalled, install } = usePWAInstall()
  const [dismissed, setDismissed] = useState(
    () => localStorage.getItem('pwa-dismissed') === '1'
  )

  if (!isInstallable || isInstalled || dismissed) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 80, opacity: 0 }}
        animate={{ y: 0,  opacity: 1 }}
        exit={{    y: 80, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="fixed bottom-[72px] inset-x-0 z-[9000] px-3 pb-1"
      >
        <div className="max-w-lg mx-auto bg-elevated border border-primary/30 rounded-2xl p-4 shadow-[0_0_24px_rgba(59,130,246,0.2)]">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl gradient-brand flex items-center justify-center text-xl flex-shrink-0">⚡</div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-slate-100">ثبّت التطبيق</p>
              <p className="text-xs text-slate-400">وصول سريع وعمل بدون إنترنت</p>
            </div>
            <div className="flex gap-2 flex-shrink-0">
              <button
                onClick={() => { setDismissed(true); localStorage.setItem('pwa-dismissed', '1') }}
                className="text-xs text-slate-400 hover:text-slate-200 px-2 py-1 transition-colors"
              >
                لاحقاً
              </button>
              <button
                onClick={() => install().then(ok => ok && setDismissed(true))}
                className="text-xs font-bold px-3 py-1.5 gradient-brand text-white rounded-xl"
              >
                تثبيت
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  )
}

// ── Offline Indicator ──────────────────────────────────────
export function OfflineIndicator() {
  const online = useOnlineStatus()
  return (
    <AnimatePresence>
      {!online && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0  }}
          exit={{    opacity: 0, y: 20  }}
          className="fixed bottom-20 left-1/2 -translate-x-1/2 z-[9000] px-4 py-2 bg-amber-500/10 border border-amber-500/30 rounded-full text-amber-400 text-xs font-medium flex items-center gap-2"
        >
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          وضع عدم الاتصال — الرسائل ستُرسل لاحقاً
        </motion.div>
      )}
    </AnimatePresence>
  )
}
