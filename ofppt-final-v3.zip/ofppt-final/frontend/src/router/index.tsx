import { lazy, useEffect } from 'react'
import {
  createBrowserRouter, RouterProvider,
  Navigate, Outlet,
} from 'react-router-dom'
import { AppLayout } from '@components/layout/AppLayout'
import { GlobalErrorBoundary, RouteErrorBoundary, PageSuspense } from '@components/feedback/ErrorBoundaries'

// ── All pages lazy-loaded (never in initial bundle) ────────
const ChatPage       = lazy(() => import('@pages/ChatPage'))
const ModulesPage    = lazy(() => import('@pages/ModulesPage'))
const FlashcardsPage = lazy(() => import('@pages/FlashcardsPage'))
const SimulatorPage  = lazy(() => import('@pages/SimulatorPage'))
const MindmapPage    = lazy(() => import('@pages/MindmapPage'))
const SchemasPage    = lazy(() => import('@pages/SchemasPage'))
const VideosPage     = lazy(() => import('@pages/VideosPage'))
const QuizPage       = lazy(() => import('@pages/QuizPage'))
const SettingsPage   = lazy(() => import('@pages/SettingsPage'))
const NotFoundPage   = lazy(() => import('@pages/NotFoundPage'))

// ── Layout wrapper ─────────────────────────────────────────
function LayoutWrapper() {
  return (
    <AppLayout>
      <PageSuspense>
        <Outlet />
      </PageSuspense>
    </AppLayout>
  )
}

// ── Router ─────────────────────────────────────────────────
const router = createBrowserRouter([
  {
    path:         '/',
    element:      <LayoutWrapper />,
    errorElement: <RouteErrorBoundary />,
    children: [
      { index: true,       element: <Navigate to="/chat" replace /> },
      { path: 'chat',      element: <ChatPage /> },
      { path: 'modules',   element: <ModulesPage /> },
      { path: 'flashcards',element: <FlashcardsPage /> },
      { path: 'simulator', element: <SimulatorPage /> },
      { path: 'mindmap',   element: <MindmapPage /> },
      { path: 'schemas',   element: <SchemasPage /> },
      { path: 'videos',    element: <VideosPage /> },
      { path: 'quiz',      element: <QuizPage /> },
      { path: 'settings',  element: <SettingsPage /> },
      { path: '*',         element: <NotFoundPage /> },
    ],
  },
])

// ── Route prefetcher on hover ──────────────────────────────
export function prefetchRoute(path: string) {
  const map: Record<string, () => Promise<any>> = {
    '/chat':       () => import('@pages/ChatPage'),
    '/modules':    () => import('@pages/ModulesPage'),
    '/flashcards': () => import('@pages/FlashcardsPage'),
    '/simulator':  () => import('@pages/SimulatorPage'),
    '/mindmap':    () => import('@pages/MindmapPage'),
    '/quiz':       () => import('@pages/QuizPage'),
    '/settings':   () => import('@pages/SettingsPage'),
  }
  map[path]?.()
}

export function AppRouter() {
  // Prefetch likely routes on idle
  useEffect(() => {
    const id = requestIdleCallback(() => {
      prefetchRoute('/chat')
      prefetchRoute('/modules')
    }, { timeout: 3000 })
    return () => cancelIdleCallback(id)
  }, [])

  return (
    <GlobalErrorBoundary>
      <RouterProvider router={router} />
    </GlobalErrorBoundary>
  )
}
