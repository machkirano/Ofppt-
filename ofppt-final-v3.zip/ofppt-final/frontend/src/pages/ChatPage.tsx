import { useRef, useEffect, useState, useCallback, memo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Send, Mic, MicOff, Copy, Brain, Layers, Volume2, RefreshCw } from 'lucide-react'
import { useChatStore, useAIStore, useGamStore, useUIStore } from '@store/index'
import { processAIRequest, createSpeechRecognizer, speak, stopSpeaking } from '@ai/ai.service'
import { cn } from '@utils/vitals'
import type { AIMessage } from '@ai/ai.service'

// ── Markdown → HTML formatter (no deps) ───────────────────
function formatMarkdown(text: string): string {
  return text
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/```([\s\S]*?)```/g,'<pre class="bg-black/30 border border-white/10 rounded-xl p-3 text-xs overflow-x-auto my-2 font-mono"><code>$1</code></pre>')
    .replace(/`([^`]+)`/g,'<code class="bg-black/30 px-1.5 py-0.5 rounded text-emerald-400 text-xs font-mono">$1</code>')
    .replace(/\*\*(.+?)\*\*/g,'<strong class="font-bold text-slate-100">$1</strong>')
    .replace(/^### (.+)$/gm,'<h4 class="text-accent font-bold text-sm mt-3 mb-1">$1</h4>')
    .replace(/^## (.+)$/gm,'<h3 class="text-primary font-bold text-base mt-3 mb-1">$1</h3>')
    .replace(/^[•\-] (.+)$/gm,'<li class="list-disc list-inside text-slate-300 text-sm py-0.5">$1</li>')
    .split('\n\n').join('</p><p class="mb-2">')
    .split('\n').join('<br/>')
}

// ── Schema keyword linkifier ───────────────────────────────
const KEYWORDS = [
  { re: /star[-\s]delta/gi,  label:'⭐ star-delta' },
  { re: /نجمة[-\s]مثلث/g,   label:'⭐ نجمة-مثلث' },
  { re: /\bRLC\b/g,          label:'🔄 RLC'       },
  { re: /محرك\s+AC/g,        label:'⚙️ محرك AC'   },
]

function linkify(html: string): string {
  let r = html
  KEYWORDS.forEach(({ re, label }) => {
    r = r.replace(re, `<span class="inline-flex items-center gap-0.5 px-1.5 py-0.5 text-xs font-semibold bg-primary/10 border border-primary/20 text-blue-300 rounded cursor-pointer hover:bg-primary/20 transition-colors" title="اضغط لعرض المخطط">${label} 📐</span>`)
  })
  return r
}

// ── Welcome card ───────────────────────────────────────────
function WelcomeCard({ onSuggest }: { onSuggest: (t:string)=>void }) {
  const suggestions = ['اشرح لي قانون أوم','ما هو star-delta؟','اشرح دوائر RLC','كيف يعمل محرك AC؟']
  return (
    <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{type:'spring',stiffness:200,damping:25}}
      className="max-w-md mx-auto my-6 p-7 bg-elevated border border-white/[0.05] rounded-2xl relative overflow-hidden">
      <div className="absolute top-0 inset-x-0 h-0.5 bg-gradient-to-r from-blue-700 via-primary via-secondary to-accent" />
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />
      <motion.div animate={{boxShadow:['0 0 16px rgba(59,130,246,0.3)','0 0 32px rgba(59,130,246,0.55)','0 0 16px rgba(59,130,246,0.3)']}} transition={{duration:3,repeat:Infinity}}
        className="w-12 h-12 rounded-2xl gradient-brand flex items-center justify-center text-xl mx-auto mb-4">⚡</motion.div>
      <h2 className="font-display font-bold text-lg text-slate-100 text-center mb-1">مساعد OFPPT الذكي</h2>
      <p className="text-slate-400 text-xs text-center mb-5">هندسة كهربائية · هندسة الطاقة · مجاني 100%</p>
      <div className="space-y-1.5 mb-5">
        {[['📚','شرح الدروس مع أمثلة'],['📇','بطاقات تعليمية تلقائية'],['🔬','محاكي الدوائر التفاعلي'],['🎤','إجابة صوتية مجانية']].map(([i,t])=>(
          <div key={t} className="flex items-center gap-2.5 p-2 bg-white/[0.02] border border-white/[0.04] rounded-xl text-xs text-slate-300">{i} {t}</div>
        ))}
      </div>
      <div className="flex flex-wrap gap-1.5">
        {suggestions.map(s => (
          <button key={s} onClick={()=>onSuggest(s)}
            className="text-xs px-2.5 py-1 bg-white/[0.03] border border-white/[0.05] rounded-full text-slate-400 hover:border-primary/30 hover:text-slate-200 transition-all">
            {s}
          </button>
        ))}
      </div>
    </motion.div>
  )
}

// ── Typing indicator ────────────────────────────────────────
const TypingIndicator = memo(function TypingIndicator() {
  return (
    <motion.div initial={{opacity:0,y:6}} animate={{opacity:1,y:0}} exit={{opacity:0}} className="flex gap-2.5 items-start mb-3">
      <div className="w-8 h-8 rounded-xl bg-raised border border-primary/20 flex items-center justify-center text-xs flex-shrink-0">✦</div>
      <div className="flex items-center gap-1 px-4 py-3 bg-elevated border border-white/[0.05] rounded-xl">
        {[0,1,2].map(i=>(
          <motion.div key={i} animate={{scale:[0.7,1.1,0.7],opacity:[0.4,1,0.4],backgroundColor:['#4E5C78','#3B82F6','#4E5C78']}}
            transition={{duration:1.4,repeat:Infinity,delay:i*0.2}} className="w-1.5 h-1.5 rounded-full bg-slate-500" />
        ))}
      </div>
    </motion.div>
  )
})

// ── Single message ─────────────────────────────────────────
const ChatMessage = memo(function ChatMessage({ msg, onSpeak }: { msg: AIMessage; onSpeak:(text:string)=>void }) {
  const isUser = msg.role === 'user'
  const [copied, setCopied] = useState(false)

  const copy = () => {
    navigator.clipboard.writeText(msg.content).then(()=>{ setCopied(true); setTimeout(()=>setCopied(false),1800) })
  }

  const html = isUser
    ? msg.content
    : linkify(formatMarkdown(msg.content))

  return (
    <motion.div initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} transition={{type:'spring',stiffness:300,damping:32}}
      className={cn('flex gap-2.5 mb-3', isUser && 'flex-row-reverse')}>
      {!isUser && (
        <div className="w-8 h-8 rounded-xl bg-raised border border-primary/20 flex items-center justify-center text-xs flex-shrink-0 self-start mt-0.5 shadow-[0_0_12px_rgba(59,130,246,0.2)]">✦</div>
      )}
      <div className={cn('max-w-[86%]', isUser && 'items-end flex flex-col')}>
        <div className={cn('relative rounded-xl px-3.5 py-2.5',
          isUser
            ? 'bg-gradient-to-br from-blue-700 to-primary text-white rounded-tr-sm border border-blue-500/30 shadow-[0_0_16px_rgba(59,130,246,0.25)]'
            : 'bg-elevated border border-white/[0.05] rounded-tl-sm before:absolute before:top-0 before:inset-x-0 before:h-px before:bg-gradient-to-r before:from-transparent before:via-primary/20 before:to-transparent'
        )}>
          {!isUser && (
            <div className="flex items-center justify-between gap-3 mb-1.5">
              <span className="text-[10px] font-bold text-primary">المساعد الذكي</span>
            </div>
          )}
          <div className={cn('text-sm leading-relaxed', isUser ? 'text-white' : 'text-slate-200')}
            dangerouslySetInnerHTML={{__html: html}} />
        </div>

        {!isUser && (
          <div className="flex flex-wrap gap-1 mt-1.5 ml-1">
            {[
              { icon:<Copy size={10}/>,    label: copied?'✓':'نسخ',  action: copy },
              { icon:<Volume2 size={10}/>, label:'استماع', action:()=>onSpeak(msg.content) },
            ].map(btn=>(
              <button key={btn.label} onClick={btn.action}
                className="flex items-center gap-1 px-2 py-0.5 text-[10px] text-slate-400 hover:text-slate-200 bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.04] hover:border-primary/20 rounded-full transition-all">
                {btn.icon}{btn.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </motion.div>
  )
})

// ── Chat Input ──────────────────────────────────────────────
function ChatInput({ onSend, disabled }: { onSend:(text:string)=>void; disabled:boolean }) {
  const [text, setText]       = useState('')
  const [recording, setRec]   = useState(false)
  const [interimText, setInterim] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)
  const recRef   = useRef<{start:()=>void;stop:()=>void}|null>(null)
  const { language } = useAIStore()

  function send() {
    const t = (text + interimText).trim()
    if (!t || disabled) return
    onSend(t); setText(''); setInterim(''); inputRef.current?.focus()
  }

  function toggleVoice() {
    if (recording) { recRef.current?.stop(); setRec(false); return }
    const rec = createSpeechRecognizer({
      language,
      onResult: (t, final) => { if (final) { setText(p=>p+t+' '); setInterim('') } else setInterim(t) },
      onError:  () => setRec(false),
      onEnd:    () => setRec(false),
    })
    if (!rec) { alert('المتصفح لا يدعم التعرف على الصوت'); return }
    recRef.current = rec
    rec.start(); setRec(true)
  }

  return (
    <div className="fixed bottom-[64px] inset-x-0 z-[100] px-3 py-2 glass border-t border-white/[0.05] after:absolute after:top-[-1px] after:inset-x-0 after:h-px after:bg-gradient-to-r after:from-transparent after:via-primary/30 after:to-transparent">
      {interimText && (
        <div className="max-w-2xl mx-auto mb-1.5 text-xs text-slate-400 px-1 truncate">{interimText}...</div>
      )}
      <div className="max-w-2xl mx-auto flex items-center gap-2">
        <button onClick={toggleVoice}
          className={cn('w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 border transition-all',
            recording ? 'bg-rose-500/15 border-rose-500/40 text-rose-400 animate-record' : 'bg-white/[0.04] border-white/[0.06] text-slate-400 hover:border-primary/20 hover:text-slate-200'
          )}>
          {recording ? <MicOff size={15}/> : <Mic size={15}/>}
        </button>

        <input ref={inputRef} value={text} onChange={e=>setText(e.target.value)}
          onKeyDown={e=>{ if(e.key==='Enter'&&!e.shiftKey){ e.preventDefault(); send() } }}
          placeholder="اكتب سؤالك... (عربية، فرنسية، دارجة)"
          disabled={disabled}
          className="flex-1 min-w-0 bg-white/[0.04] border border-white/[0.06] rounded-2xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 outline-none focus:border-primary/50 focus:ring-2 focus:ring-primary/10 transition-all disabled:opacity-50" />

        <motion.button whileHover={{scale:disabled?1:1.08}} whileTap={{scale:disabled?1:0.94}}
          onClick={send} disabled={!text.trim()&&!interimText||disabled}
          className="w-10 h-10 rounded-full gradient-brand flex items-center justify-center flex-shrink-0 shadow-[0_0_16px_rgba(59,130,246,0.3)] disabled:opacity-40 disabled:shadow-none transition-all">
          <Send size={14} className="text-white -rotate-180"/>
        </motion.button>
      </div>
    </div>
  )
}

// ── ChatPage ────────────────────────────────────────────────
export default function ChatPage() {
  const chatStore  = useChatStore()
  const aiStore    = useAIStore()
  const { addXP }  = useGamStore()
  const { toast, specialty } = useUIStore()
  const bottomRef  = useRef<HTMLDivElement>(null)

  // Ensure active chat exists
  const chatId = chatStore.activeChatId ?? chatStore.newChat()
  const chat   = chatStore.chats.find(c=>c.id===chatId)
  const msgs   = chat?.messages ?? []

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [msgs.length, chatStore.isTyping])

  const sendMessage = useCallback(async (rawText: string) => {
    if (chatStore.isTyping) return
    const text = rawText.trim()
    if (!text) return

    const cid = chatStore.activeChatId ?? chatStore.newChat()
    chatStore.addMsg(cid, { role:'user', content:text })
    chatStore.setTyping(true)

    const history: AIMessage[] = (chatStore.chats.find(c=>c.id===cid)?.messages ?? [])
      .slice(-aiStore.contextLen).map(m=>({ role:m.role, content:m.content }))

    try {
      const result = await processAIRequest({
        userId:    'local_user',
        prompt:    text,
        history,
        specialty,
        language:  aiStore.language,
        level:     aiStore.level,
        weakTopics:[], 
        apiKey:    aiStore.apiKey,
      })

      chatStore.addMsg(cid, { role:'assistant', content: result.content })
      aiStore.addTokens(result.tokens)
      addXP(5)
      if (result.cached) toast('⚡ من الكاش', 'info')
    } catch (err: any) {
      const msg = err.message?.includes('RATE_LIMITED')
        ? '⏱ تجاوزت الحد — انتظر دقيقة'
        : `❌ ${err.message ?? 'خطأ في الاتصال'}`
      chatStore.addMsg(cid, { role:'assistant', content: msg })
      toast(msg.slice(0,50), 'error')
    } finally {
      chatStore.setTyping(false)
    }
  }, [chatStore, aiStore, addXP, toast, specialty])

  const handleSpeak = useCallback((text: string) => {
    speak(text, aiStore.language)
  }, [aiStore.language])

  return (
    <div className="flex flex-col h-[calc(100vh-56px-64px)]">
      <div className="flex-1 overflow-y-auto no-scrollbar px-3 pt-3 pb-2">
        {msgs.length === 0
          ? <WelcomeCard onSuggest={sendMessage} />
          : (
            <AnimatePresence initial={false}>
              {msgs.map((m, i) => <ChatMessage key={i} msg={m} onSpeak={handleSpeak} />)}
            </AnimatePresence>
          )
        }
        <AnimatePresence>
          {chatStore.isTyping && <TypingIndicator />}
        </AnimatePresence>
        <div ref={bottomRef} />
      </div>
      <ChatInput onSend={sendMessage} disabled={chatStore.isTyping} />
    </div>
  )
}
