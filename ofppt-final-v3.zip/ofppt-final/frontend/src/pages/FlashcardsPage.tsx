export { FlashcardsPage as default } from './SettingsPage'
