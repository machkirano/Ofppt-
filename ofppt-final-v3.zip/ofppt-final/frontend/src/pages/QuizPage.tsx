export { QuizPage as default } from './SettingsPage'
