export { SchemasPage as default } from './SettingsPage'
