export { SimulatorPage as default } from './SettingsPage'
