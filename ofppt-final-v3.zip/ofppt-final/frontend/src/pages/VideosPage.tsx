export { VideosPage as default } from './SettingsPage'
