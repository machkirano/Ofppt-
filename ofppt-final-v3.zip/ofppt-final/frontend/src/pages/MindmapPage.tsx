export { MindmapPage as default } from './SettingsPage'
