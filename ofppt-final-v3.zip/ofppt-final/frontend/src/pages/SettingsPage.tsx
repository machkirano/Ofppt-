// ══════ src/pages/SettingsPage.tsx ════════════════════════
import { useState } from 'react'
import { motion } from 'framer-motion'
import { Eye, EyeOff, TestTube, Trash2, RefreshCw, Globe, Cpu, MessageSquare, Info } from 'lucide-react'
import { useAIStore, useChatStore, useUIStore } from '@store/index'
import { clearAICache, getCacheStats } from '@ai/ai.service'
import type { Language, Specialty } from '@ai/ai.service'

function Section({ title, icon, children }: { title:string; icon:React.ReactNode; children:React.ReactNode }) {
  return (
    <div className="bg-elevated border border-white/[0.05] rounded-xl overflow-hidden mb-3">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-white/[0.04]">
        <span className="text-primary">{icon}</span>
        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{title}</span>
      </div>
      <div className="p-4 space-y-3">{children}</div>
    </div>
  )
}

function Toggle({ label, checked, onChange }: { label:string; checked:boolean; onChange:(v:boolean)=>void }) {
  return (
    <div className="flex items-center justify-between py-0.5">
      <span className="text-sm text-slate-300">{label}</span>
      <button onClick={()=>onChange(!checked)}
        className={`relative w-10 h-5 rounded-full transition-colors ${checked?'bg-primary':'bg-white/10'}`}>
        <motion.div animate={{x: checked ? 18 : 2}} transition={{type:'spring',stiffness:500,damping:32}}
          className="absolute top-[3px] w-4 h-4 bg-white rounded-full shadow" />
      </button>
    </div>
  )
}

export default function SettingsPage() {
  const ai = useAIStore()
  const { clearAll } = useChatStore()
  const { toast, specialty, setSpecialty } = useUIStore()
  const [showKey, setShowKey] = useState(false)
  const [testing, setTesting] = useState(false)

  async function testKey() {
    if (!ai.apiKey) { toast('أدخل مفتاح API أولاً','warning'); return }
    setTesting(true)
    try {
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${ai.apiKey}`,
        { signal: AbortSignal.timeout(8000) })
      toast(r.ok ? '✅ الاتصال ناجح!':'❌ المفتاح غير صحيح', r.ok?'success':'error')
    } catch { toast('❌ فشل الاتصال','error') }
    setTesting(false)
  }

  const stats = getCacheStats()
  const tokenPct = Math.min(100, (ai.tokensUsed / ai.tokenLimit) * 100)

  return (
    <div className="max-w-lg mx-auto px-4 py-5">
      <div className="mb-4">
        <h1 className="font-display font-bold text-xl text-slate-100">الإعدادات</h1>
        <p className="text-xs text-slate-400 mt-0.5">كل شيء مجاني 100%</p>
      </div>

      {/* FREE tier notice */}
      <div className="mb-3 p-3 bg-emerald-500/8 border border-emerald-500/20 rounded-xl flex items-start gap-2.5">
        <span className="text-emerald-400 mt-0.5">✅</span>
        <div className="text-xs text-emerald-300 leading-relaxed">
          <strong>مجاني تماماً</strong> — يستخدم Gemini 1.5 Flash (15 طلب/دقيقة مجاناً) والـ Web Speech API المدمجة في المتصفح.{' '}
          <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="underline">احصل على مفتاحك المجاني هنا ←</a>
        </div>
      </div>

      <Section title="مزود الذكاء الاصطناعي" icon={<Cpu size={13}/>}>
        <div>
          <div className="text-xs text-slate-400 mb-2">المزود (مجاني)</div>
          <div className="flex gap-2">
            {(['gemini','local'] as const).map(p=>(
              <button key={p} onClick={()=>ai.setConfig({provider:p})}
                className={`flex-1 py-2 text-xs font-semibold rounded-xl border transition-all ${ai.provider===p?'bg-primary/15 border-primary/40 text-primary':'bg-white/[0.02] border-white/[0.05] text-slate-400 hover:bg-white/[0.04]'}`}>
                {p==='gemini'?'✨ Gemini (مجاني)':'📚 محلي (بدون API)'}
              </button>
            ))}
          </div>
        </div>

        {ai.provider === 'gemini' && (
          <div>
            <div className="text-xs text-slate-400 mb-1.5">مفتاح Gemini API (مجاني)</div>
            <div className="flex gap-2">
              <input type={showKey?'text':'password'} value={ai.apiKey} onChange={e=>ai.setApiKey(e.target.value)}
                placeholder="AIzaSy..."
                className="flex-1 bg-white/[0.04] border border-white/[0.06] rounded-xl px-3 py-2 text-sm text-slate-100 placeholder:text-slate-500 outline-none focus:border-primary/50 transition-all font-mono text-xs" />
              <button onClick={()=>setShowKey(s=>!s)} className="w-9 h-9 flex items-center justify-center bg-white/[0.04] border border-white/[0.06] rounded-xl text-slate-400 hover:text-slate-200 transition-colors">
                {showKey?<EyeOff size={13}/>:<Eye size={13}/>}
              </button>
            </div>
            <div className="flex gap-2 mt-2">
              <button onClick={testKey} disabled={testing}
                className="flex-1 flex items-center justify-center gap-1.5 py-1.5 text-xs border border-white/[0.08] rounded-xl text-slate-300 hover:bg-white/[0.04] transition-all disabled:opacity-50">
                <TestTube size={11}/> {testing?'جاري...':'اختبار الاتصال'}
              </button>
              <button onClick={()=>{ ai.setApiKey(''); toast('تم مسح المفتاح','info') }}
                className="px-3 py-1.5 text-xs border border-rose-500/20 rounded-xl text-rose-400 hover:bg-rose-500/10 transition-all">
                مسح
              </button>
            </div>
          </div>
        )}
      </Section>

      <Section title="استخدام الرموز (مجاني 50k/يوم)" icon={<Info size={13}/>}>
        <div>
          <div className="flex justify-between text-xs mb-1.5">
            <span className="text-slate-400">{ai.tokensUsed.toLocaleString()} مستخدم</span>
            <span className="text-slate-400">{ai.tokenLimit.toLocaleString()} حد يومي</span>
          </div>
          <div className="h-2 bg-white/[0.05] rounded-full overflow-hidden">
            <motion.div animate={{width:`${tokenPct}%`}} transition={{duration:0.6}}
              className={`h-full rounded-full ${tokenPct>80?'bg-gradient-to-r from-rose-500 to-amber-500':'bg-gradient-to-r from-blue-700 to-primary'}`} />
          </div>
          <button onClick={()=>{ ai.resetTokens(); toast('✅ تم إعادة تعيين الحساب','success') }}
            className="mt-2 flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 transition-colors">
            <RefreshCw size={11}/> إعادة تعيين
          </button>
        </div>
      </Section>

      <Section title="اللغة والتخصص" icon={<Globe size={13}/>}>
        <div>
          <div className="text-xs text-slate-400 mb-1.5">لغة الذكاء الاصطناعي</div>
          <div className="flex gap-2">
            {(['AR','FR','DARIJA'] as Language[]).map(l=>(
              <button key={l} onClick={()=>ai.setLanguage(l)}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-xl border transition-all ${ai.language===l?'bg-primary/15 border-primary/40 text-primary':'bg-white/[0.02] border-white/[0.05] text-slate-400 hover:bg-white/[0.04]'}`}>
                {l==='AR'?'🇲🇦 عربية':l==='FR'?'🇫🇷 فرنسية':'💬 دارجة'}
              </button>
            ))}
          </div>
        </div>
        <div>
          <div className="text-xs text-slate-400 mb-1.5">التخصص</div>
          <div className="flex gap-2">
            {(['GE','GEN'] as Specialty[]).map(s=>(
              <button key={s} onClick={()=>setSpecialty(s)}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-xl border transition-all ${specialty===s?'bg-primary/15 border-primary/40 text-primary':'bg-white/[0.02] border-white/[0.05] text-slate-400 hover:bg-white/[0.04]'}`}>
                {s==='GE'?'⚡ GE — كهربائية':'☀️ GEn — طاقة'}
              </button>
            ))}
          </div>
        </div>
      </Section>

      <Section title="سلوك الذكاء الاصطناعي" icon={<MessageSquare size={13}/>}>
        <Toggle label="ردود تفصيلية" checked={ai.verbose} onChange={v=>ai.setConfig({verbose:v})} />
        <div>
          <div className="flex justify-between text-xs mb-1">
            <span className="text-slate-300">طول السياق</span>
            <span className="text-primary font-mono">{ai.contextLen} رسائل</span>
          </div>
          <input type="range" min={3} max={16} value={ai.contextLen}
            onChange={e=>ai.setConfig({contextLen:+e.target.value})}
            className="w-full accent-primary" />
        </div>
      </Section>

      <Section title="الكاش والتخزين" icon={<Trash2 size={13}/>}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-slate-200">كاش الإجابات (5 دقائق)</p>
            <p className="text-xs text-slate-500">{stats.size} إجابة مخزنة</p>
          </div>
          <button onClick={()=>{ clearAICache(); toast('✅ تم مسح الكاش','success') }}
            className="text-xs px-3 py-1.5 border border-white/[0.08] rounded-xl text-slate-300 hover:bg-white/[0.04] transition-all">مسح</button>
        </div>
        <div className="flex items-center justify-between pt-2.5 border-t border-white/[0.05]">
          <div>
            <p className="text-sm text-slate-200">سجل المحادثات</p>
            <p className="text-xs text-slate-500">حذف جميع المحادثات</p>
          </div>
          <button onClick={()=>{ if(confirm('حذف كل المحادثات؟')){ clearAll(); toast('✅ تم المسح','success') } }}
            className="text-xs px-3 py-1.5 border border-rose-500/20 rounded-xl text-rose-400 hover:bg-rose-500/10 transition-all">حذف</button>
        </div>
      </Section>

      <div className="bg-elevated border border-white/[0.05] rounded-xl p-4 text-center">
        <div className="text-3xl mb-2">⚡</div>
        <p className="font-display font-bold text-slate-100 text-sm mb-2">OFPPT Smart Assistant v3.0</p>
        <div className="flex flex-wrap justify-center gap-1.5 text-[10px]">
          {['React + Vite','Gemini Free','Web Speech API','PWA Offline','100% مجاني'].map(b=>(
            <span key={b} className="px-2 py-0.5 bg-white/[0.04] border border-white/[0.06] rounded-full text-slate-400">{b}</span>
          ))}
        </div>
      </div>
    </div>
  )
}

// ══════ Stub pages (expandable) ═══════════════════════════
export function ModulesPage()    { return <div className="px-4 py-6 text-slate-400 text-center">📚 الوحدات الدراسية — قريباً</div> }
export function FlashcardsPage() { return <div className="px-4 py-6 text-slate-400 text-center">📇 البطاقات التعليمية — قريباً</div> }
export function SimulatorPage()  { return <div className="px-4 py-6 text-slate-400 text-center">🔬 المحاكي — قريباً</div> }
export function MindmapPage()    { return <div className="px-4 py-6 text-slate-400 text-center">🧠 الخريطة الذهنية — قريباً</div> }
export function SchemasPage()    { return <div className="px-4 py-6 text-slate-400 text-center">📐 المخططات — قريباً</div> }
export function VideosPage()     { return <div className="px-4 py-6 text-slate-400 text-center">🎬 الفيديوهات — قريباً</div> }
export function QuizPage()       { return <div className="px-4 py-6 text-slate-400 text-center">⚡ الاختبارات — قريباً</div> }
export function NotFoundPage()   {
  return (
    <div className="flex flex-col items-center justify-center h-[60vh] gap-4 px-4 text-center">
      <div className="text-4xl">🔌</div>
      <h2 className="font-display font-bold text-xl text-slate-100">الصفحة غير موجودة</h2>
      <a href="/chat" className="px-5 py-2.5 gradient-brand text-white rounded-xl text-sm font-semibold">← الرئيسية</a>
    </div>
  )
}
