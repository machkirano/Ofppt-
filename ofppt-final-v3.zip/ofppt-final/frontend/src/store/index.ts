// ══════ src/store/index.ts ═══════════════════════════════
import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import { immer } from 'zustand/middleware/immer'
import type { AIMessage, Language, Specialty, Level } from '@ai/ai.service'

// ── UI Store ─────────────────────────────────────────────
interface UIState {
  sidebarOpen:  boolean
  isOnline:     boolean
  toasts:       { id: string; msg: string; type: 'success'|'error'|'info'|'warning' }[]
  specialty:    Specialty
}
interface UIActions {
  toggleSidebar:()=>void
  closeSidebar: ()=>void
  setOnline:    (v:boolean)=>void
  toast:        (msg:string, type?:UIState['toasts'][0]['type'])=>void
  removeToast:  (id:string)=>void
  setSpecialty: (s:Specialty)=>void
}

export const useUIStore = create<UIState & UIActions>()(
  persist(
    immer((set, get) => ({
      sidebarOpen: false,
      isOnline:    true,
      toasts:      [],
      specialty:   'GE',
      toggleSidebar: ()=> set(s=>{ s.sidebarOpen = !s.sidebarOpen }),
      closeSidebar:  ()=> set(s=>{ s.sidebarOpen = false }),
      setOnline:  v => set(s=>{ s.isOnline = v }),
      setSpecialty:s => set(st=>{ st.specialty = s }),
      toast: (msg, type='info') => {
        const id = `${Date.now()}_${Math.random().toString(36).slice(2,7)}`
        set(s=>{ s.toasts.push({ id, msg, type }) })
        setTimeout(() => get().removeToast(id), 3500)
      },
      removeToast: id => set(s=>{ s.toasts = s.toasts.filter(t=>t.id!==id) }),
    })),
    { name:'ofppt-ui', storage:createJSONStorage(()=>localStorage), partialize:(s)=>({ specialty:s.specialty }) }
  )
)

// ── AI Store ──────────────────────────────────────────────
interface AIState {
  provider:    'gemini'|'local'
  apiKey:      string
  language:    Language
  level:       Level
  verbose:     boolean
  contextLen:  number
  tokensUsed:  number
  tokenLimit:  number
  resetDate:   string
  weakTopics:  string[]
}
interface AIActions {
  setApiKey:   (k:string)=>void
  setLanguage: (l:Language)=>void
  setLevel:    (l:Level)=>void
  setConfig:   (p:Partial<AIState>)=>void
  addTokens:   (n:number)=>void
  resetTokens: ()=>void
  canAfford:   (n:number)=>boolean
  addWeakTopic:(t:string)=>void
}

export const useAIStore = create<AIState & AIActions>()(
  persist(
    immer((set,get)=>({
      provider:   'gemini',
      apiKey:     '',
      language:   'AR',
      level:      'intermediate',
      verbose:    true,
      contextLen: 8,
      tokensUsed: 0,
      tokenLimit: 50000,
      resetDate:  new Date().toDateString(),
      weakTopics: [],
      setApiKey:  k=>set(s=>{ s.apiKey=k }),
      setLanguage:l=>set(s=>{ s.language=l }),
      setLevel:   l=>set(s=>{ s.level=l }),
      setConfig:  p=>set(s=>{ Object.assign(s,p) }),
      addTokens:  n=>set(s=>{
        const today=new Date().toDateString()
        if(s.resetDate!==today){ s.tokensUsed=0; s.resetDate=today }
        s.tokensUsed+=n
      }),
      resetTokens:()=>set(s=>{ s.tokensUsed=0; s.resetDate=new Date().toDateString() }),
      canAfford:  n=>(get().tokensUsed+n)<=get().tokenLimit,
      addWeakTopic:t=>set(s=>{
        if(!s.weakTopics.includes(t)){ s.weakTopics.unshift(t); if(s.weakTopics.length>10) s.weakTopics.pop() }
      }),
    })),
    { name:'ofppt-ai', storage:createJSONStorage(()=>localStorage) }
  )
)

// ── Chat Store ────────────────────────────────────────────
interface Chat { id:string; title:string; messages:AIMessage[]; createdAt:number }
interface ChatState { chats:Chat[]; activeChatId:string|null; isTyping:boolean }
interface ChatActions {
  newChat:    ()=>string
  addMsg:     (chatId:string,msg:AIMessage)=>void
  setTyping:  (v:boolean)=>void
  getActive:  ()=>Chat|undefined
  clearAll:   ()=>void
}

export const useChatStore = create<ChatState & ChatActions>()(
  persist(
    immer((set,get)=>({
      chats:        [],
      activeChatId: null,
      isTyping:     false,
      newChat:()=>{
        const id=`chat_${Date.now()}`
        set(s=>{ s.chats.unshift({id,title:'محادثة جديدة',messages:[],createdAt:Date.now()}); s.activeChatId=id })
        return id
      },
      addMsg:(chatId,msg)=>set(s=>{
        const c=s.chats.find(x=>x.id===chatId)
        if(c){ c.messages.push(msg); if(c.messages.length===1&&msg.role==='user') c.title=msg.content.slice(0,40) }
      }),
      setTyping:v=>set(s=>{ s.isTyping=v }),
      getActive:()=>{ const {chats,activeChatId}=get(); return chats.find(c=>c.id===activeChatId) },
      clearAll: ()=>set(s=>{ s.chats=[]; s.activeChatId=null }),
    })),
    {
      name:'ofppt-chat', storage:createJSONStorage(()=>localStorage),
      partialize:s=>({ chats:s.chats.slice(0,20).map(c=>({...c,messages:c.messages.slice(-50)})), activeChatId:s.activeChatId })
    }
  )
)

// ── Gamification Store ────────────────────────────────────
interface GamState { xp:number; level:number; streak:number; badges:string[] }
interface GamActions { addXP:(n:number)=>void; setStreak:(n:number)=>void }

export const useGamStore = create<GamState & GamActions>()(
  persist(
    immer((set)=>({
      xp:0, level:1, streak:0, badges:[],
      addXP: n=>set(s=>{
        s.xp+=n
        const needed=s.level*100
        if(s.xp>=needed){ s.level++; s.xp-=needed; s.badges.push(`level_${s.level}`) }
      }),
      setStreak: n=>set(s=>{ s.streak=n }),
    })),
    { name:'ofppt-gam', storage:createJSONStorage(()=>localStorage) }
  )
)
