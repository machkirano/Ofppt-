// ═══════════════════════════════════════════════════════════
// FREE AI SERVICE — 100% free, no paid APIs
//
// Priority:
// 1. Browser Web Speech API (STT/TTS) — FREE, no key needed
// 2. Tesseract.js (OCR) — FREE, runs in browser
// 3. Gemini FREE tier (gemini-1.5-flash) — 15 req/min free
// 4. Local fallback responses — always free
// ═══════════════════════════════════════════════════════════

import { useAIStore } from '@store/index'

// ── Types ──────────────────────────────────────────────────
export type Language  = 'AR' | 'FR' | 'DARIJA'
export type Specialty = 'GE' | 'GEN'
export type Level     = 'beginner' | 'intermediate' | 'advanced'

export interface AIMessage { role: 'user' | 'assistant'; content: string }

export interface AIResult {
  content:  string
  provider: 'gemini' | 'local' | 'cache'
  cached:   boolean
  tokens:   number
}

// ── Short intelligent cache (5 min, userId+hash) ──────────
const responseCache = new Map<string, { content: string; expiry: number; tokens: number }>()
const CACHE_TTL_MS  = 5 * 60 * 1000  // 5 minutes

function cacheKey(userId: string, prompt: string, specialty: string): string {
  // Simple djb2 hash
  const str = `${userId}:${specialty}:${prompt.trim().toLowerCase().slice(0, 300)}`
  let   h   = 5381
  for (let i = 0; i < str.length; i++) h = ((h << 5) + h) ^ str.charCodeAt(i)
  return `ai:${Math.abs(h).toString(36)}`
}

function getCached(key: string): { content: string; tokens: number } | null {
  const entry = responseCache.get(key)
  if (!entry) return null
  if (Date.now() > entry.expiry) { responseCache.delete(key); return null }
  return { content: entry.content, tokens: entry.tokens }
}

function setCache(key: string, content: string, tokens: number): void {
  // Evict oldest if > 100 entries
  if (responseCache.size >= 100) {
    const oldest = [...responseCache.entries()].sort((a,b) => a[1].expiry - b[1].expiry)[0]
    responseCache.delete(oldest[0])
  }
  responseCache.set(key, { content, tokens, expiry: Date.now() + CACHE_TTL_MS })
}

// ── System prompt builder ──────────────────────────────────
function buildSystemPrompt(specialty: Specialty, language: Language, level: Level, weakTopics: string[]): string {
  const sName   = specialty === 'GE' ? 'Génie Électrique (الهندسة الكهربائية)' : 'Génie Énergétique (هندسة الطاقة)'
  const langMap = { AR: 'أجب بالعربية الفصحى.', FR: 'Réponds en français.', DARIJA: 'أجب بالدارجة المغربية.' }
  const lvlMap  = {
    beginner:     'الطالب مبتدئ — استخدم أمثلة بسيطة وخطوات صغيرة.',
    intermediate: 'الطالب في المستوى المتوسط — أمثلة عملية صناعية.',
    advanced:     'الطالب متقدم — تحليل نظري عميق وصيغ رياضية.',
  }
  const weakSection = weakTopics.length > 0 ? `\n⚠️ نقاط ضعف: ${weakTopics.slice(0,3).join('، ')}` : ''

  return `أنت مساعد تعليمي ذكي لطلاب OFPPT تخصص ${sName}.
${langMap[language]} ${lvlMap[level]}${weakSection}
قواعد: اذكر الصيغ الرياضية بوضوح · قدم مثالاً عملياً · رفض أي سؤال خارج الهندسة الكهربائية/الطاقة.
المواضيع: قانون أوم، RLC، محركات AC/DC، PLC، GRAFCET، star-delta، الطاقة الشمسية، طاقة الرياح.`
}

// ── Prompt injection sanitizer ─────────────────────────────
const INJECTIONS = [
  /ignore\s+previous/i, /forget\s+your/i, /you\s+are\s+now/i,
  /jailbreak/i, /DAN\s+mode/i, /system\s+prompt/i,
]

function sanitize(text: string): string {
  let clean = text.trim().slice(0, 2000)
  for (const p of INJECTIONS) clean = clean.replace(p, '[blocked]')
  return clean
}

// ── Free Gemini API call (flash model — 15 req/min free) ───
async function callGemini(params: {
  systemPrompt: string
  history:      AIMessage[]
  userPrompt:   string
  apiKey:        string
  maxTokens:    number
}): Promise<{ content: string; tokens: number }> {
  const MODEL  = 'gemini-1.5-flash'                // FREE tier
  const url    = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${params.apiKey}`

  const body = {
    system_instruction: { parts: [{ text: params.systemPrompt }] },
    contents: [
      ...params.history.map(m => ({
        role:  m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }],
      })),
      { role: 'user', parts: [{ text: params.userPrompt }] },
    ],
    generationConfig: {
      temperature:     0.7,
      topK:            40,
      topP:            0.95,
      maxOutputTokens: params.maxTokens,
    },
  }

  const controller = new AbortController()
  const timeout    = setTimeout(() => controller.abort(), 25_000)

  const resp = await fetch(url, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
    signal:  controller.signal,
  }).finally(() => clearTimeout(timeout))

  if (resp.status === 429) throw new Error('RATE_LIMITED')
  if (!resp.ok) {
    const e = await resp.json().catch(() => ({})) as any
    throw new Error(`Gemini ${resp.status}: ${e?.error?.message ?? 'error'}`)
  }

  const data = await resp.json() as any
  return {
    content: data.candidates?.[0]?.content?.parts?.[0]?.text ?? '',
    tokens:  data.usageMetadata?.totalTokenCount ?? Math.ceil(params.userPrompt.length / 4),
  }
}

// ── Local fallback responses (always free) ─────────────────
const LOCAL_RESPONSES: Record<string, string> = {
  'قانون أوم':   'قانون أوم: **V = R × I**\n• V: الجهد (فولت)\n• R: المقاومة (أوم Ω)\n• I: شدة التيار (أمبير)\n\nمثال: إذا كانت R = 100Ω و I = 0.5A فإن V = 100 × 0.5 = **50 فولت**',
  'star-delta':  'تشغيل نجمة-مثلث (Étoile-Triangle):\n1. المرحلة الأولى: تشغيل في وضع **النجمة (Y)** لتخفيض تيار الانطلاق بنسبة 1/3\n2. بعد 5-10 ثوانٍ: الانتقال إلى وضع **المثلث (Δ)** للتشغيل العادي\nالهدف: حماية المحرك والشبكة من تيارات الانطلاق العالية',
  'rlc':         'دائرة RLC:\n• المقاومة R: تُبدد الطاقة كحرارة\n• المحث L: يخزن طاقة مغناطيسية (XL = 2πfL)\n• المكثف C: يخزن طاقة كهربائية (XC = 1/2πfC)\n\nالممانعة الكلية: **Z = √(R² + (XL-XC)²)**',
}

function getLocalResponse(prompt: string): string {
  const lower = prompt.toLowerCase()
  for (const [key, resp] of Object.entries(LOCAL_RESPONSES)) {
    if (lower.includes(key)) return resp
  }
  return `يمكنني مساعدتك في مواضيع الهندسة الكهربائية والطاقة مثل:\n• قانون أوم ودوائر RLC\n• المحركات الكهربائية وstar-delta\n• برمجة PLC وGRAFCET\n• الطاقة الشمسية وطاقة الرياح\n\n*ملاحظة: أضف مفتاح Gemini مجاني في الإعدادات للإجابات الذكية الكاملة*`
}

// ── Main AI process function ───────────────────────────────
export async function processAIRequest(params: {
  userId:     string
  prompt:     string
  history:    AIMessage[]
  specialty:  Specialty
  language:   Language
  level:      Level
  weakTopics: string[]
  apiKey:     string
}): Promise<AIResult> {
  const clean = sanitize(params.prompt)
  if (!clean) return { content: 'السؤال فارغ', provider: 'local', cached: false, tokens: 0 }

  // ── Cache check ────────────────────────────────────────
  const key    = cacheKey(params.userId, clean, params.specialty)
  const cached = getCached(key)
  if (cached) return { content: cached.content, provider: 'cache', cached: true, tokens: 0 }

  // ── Gemini FREE tier ───────────────────────────────────
  if (params.apiKey) {
    const systemPrompt = buildSystemPrompt(params.specialty, params.language, params.level, params.weakTopics)
    const result = await callGemini({
      systemPrompt,
      history:   params.history.slice(-8),       // last 8 turns = context
      userPrompt: clean,
      apiKey:    params.apiKey,
      maxTokens: 1500,
    })
    setCache(key, result.content, result.tokens)
    return { content: result.content, provider: 'gemini', cached: false, tokens: result.tokens }
  }

  // ── Local fallback ─────────────────────────────────────
  const local = getLocalResponse(clean)
  return { content: local, provider: 'local', cached: false, tokens: 0 }
}

// ── FREE Speech-to-Text (Web Speech API) ──────────────────
export function createSpeechRecognizer(params: {
  language:  Language
  onResult:  (text: string, isFinal: boolean) => void
  onError:   (err: string) => void
  onEnd:     () => void
}): { start: () => void; stop: () => void } | null {
  const SpeechRecognition = (window as any).SpeechRecognition ?? (window as any).webkitSpeechRecognition
  if (!SpeechRecognition) return null

  const langMap = { AR: 'ar-MA', FR: 'fr-FR', DARIJA: 'ar-MA' }
  const rec     = new SpeechRecognition()

  rec.continuous      = true
  rec.interimResults  = true
  rec.lang            = langMap[params.language]
  rec.maxAlternatives = 1

  rec.onresult = (e: any) => {
    const result  = e.results[e.results.length - 1]
    const text    = result[0].transcript
    const isFinal = result.isFinal
    params.onResult(text, isFinal)
  }

  rec.onerror = (e: any) => params.onError(e.error)
  rec.onend   = params.onEnd

  return {
    start: () => rec.start(),
    stop:  () => rec.stop(),
  }
}

// ── FREE Text-to-Speech (Web Speech API) ──────────────────
export function speak(text: string, language: Language, speed = 0.9): void {
  if (!('speechSynthesis' in window)) return
  window.speechSynthesis.cancel()
  const langMap  = { AR: 'ar-MA', FR: 'fr-FR', DARIJA: 'ar-MA' }
  const utterance = new SpeechSynthesisUtterance(text.slice(0, 1000))
  utterance.lang  = langMap[language]
  utterance.rate  = speed
  utterance.pitch = 1.0
  window.speechSynthesis.speak(utterance)
}

export function stopSpeaking(): void {
  window.speechSynthesis?.cancel()
}

// ── Cache stats ────────────────────────────────────────────
export function getCacheStats(): { size: number; hitRate: number } {
  return { size: responseCache.size, hitRate: 0 }
}

export function clearAICache(): void {
  responseCache.clear()
}
