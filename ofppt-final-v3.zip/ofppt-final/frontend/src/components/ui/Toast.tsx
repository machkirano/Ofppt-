// ══════ src/components/ui/Toast.tsx ═══════════════════════
import { motion, AnimatePresence } from 'framer-motion'

interface Toast { id: string; msg: string; type: 'success'|'error'|'info'|'warning' }

const STYLES = {
  success: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300',
  error:   'border-rose-500/30    bg-rose-500/10    text-rose-300',
  warning: 'border-amber-500/30   bg-amber-500/10   text-amber-300',
  info:    'border-blue-500/20    bg-blue-500/8     text-blue-200',
}
const ICONS = { success:'✓', error:'✕', warning:'⚠', info:'ℹ' }

export function ToastContainer({ toasts, onRemove }: { toasts: Toast[]; onRemove:(id:string)=>void }) {
  return (
    <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-[9998] flex flex-col items-center gap-2 pointer-events-none">
      <AnimatePresence mode="popLayout">
        {toasts.map(t => (
          <motion.button
            key={t.id}
            layout
            initial={{ opacity:0, y:16, scale:0.92 }}
            animate={{ opacity:1, y:0,  scale:1    }}
            exit={{    opacity:0, y:8,  scale:0.95  }}
            transition={{ type:'spring', stiffness:400, damping:30 }}
            onClick={() => onRemove(t.id)}
            className={`pointer-events-auto flex items-center gap-2.5 px-4 py-2.5 rounded-full border text-sm font-medium backdrop-blur-sm shadow-lg whitespace-nowrap max-w-[80vw] ${STYLES[t.type]}`}
          >
            <span className="text-base leading-none">{ICONS[t.type]}</span>
            <span className="truncate">{t.msg}</span>
          </motion.button>
        ))}
      </AnimatePresence>
    </div>
  )
}
