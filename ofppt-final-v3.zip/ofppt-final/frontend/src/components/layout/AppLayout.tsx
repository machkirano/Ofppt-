import React, { useEffect } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  MessageSquare, BookOpen, Layers, Cpu, Settings,
  Menu, X, Zap, Brain, Video, BarChart2, Wrench
} from 'lucide-react'
import { useUIStore, useGamStore, useAIStore } from '@store/index'
import { PWAInstallBanner, OfflineIndicator } from '@pwa/PWAManager'
import { cn } from '@utils/vitals'

const NAV = [
  { path:'/chat',       icon:MessageSquare, label:'الشات'   },
  { path:'/modules',    icon:BookOpen,      label:'الوحدات'  },
  { path:'/flashcards', icon:Layers,        label:'البطاقات' },
  { path:'/simulator',  icon:Cpu,           label:'المحاكي'  },
  { path:'/settings',   icon:Settings,      label:'الإعدادات'},
]

const SIDEBAR_NAV = [
  { section:'رئيسي',   items:[
    { path:'/chat',       icon:MessageSquare, label:'المساعد الذكي',   sub:'اسأل أي سؤال'         },
    { path:'/modules',    icon:BookOpen,       label:'الوحدات',         sub:'المنهج الدراسي'       },
  ]},
  { section:'تعلّم',   items:[
    { path:'/flashcards', icon:Layers,         label:'البطاقات التعليمية',sub:'حفظ وتكرار'         },
    { path:'/mindmap',    icon:Brain,           label:'الخريطة الذهنية', sub:'رسم المفاهيم'         },
    { path:'/simulator',  icon:Cpu,             label:'المحاكي',         sub:'دوائر تفاعلية'       },
    { path:'/quiz',       icon:Zap,             label:'الاختبارات',      sub:'قيّم نفسك'            },
    { path:'/videos',     icon:Video,           label:'الفيديوهات',      sub:'شروحات مرئية'        },
  ]},
  { section:'مراجع',  items:[
    { path:'/schemas',   icon:BarChart2,        label:'المخططات',        sub:'star-delta وغيرها'   },
  ]},
  { section:'نظام',   items:[
    { path:'/settings',  icon:Settings,         label:'الإعدادات',       sub:'AI · اللغة · الكاش' },
  ]},
]

// ── Header ─────────────────────────────────────────────────
function Header() {
  const { toggleSidebar, sidebarOpen } = useUIStore()
  const navigate = useNavigate()

  return (
    <header className="fixed top-0 inset-x-0 z-[1000] h-[56px] glass border-b border-white/[0.05] flex items-center justify-between px-3 safe-top after:absolute after:bottom-[-1px] after:inset-x-0 after:h-px after:bg-gradient-to-r after:from-transparent after:via-primary/40 after:to-transparent">
      <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => navigate('/chat')}>
        <motion.div animate={{ boxShadow:['0 0 16px rgba(59,130,246,0.3)','0 0 32px rgba(59,130,246,0.5)','0 0 16px rgba(59,130,246,0.3)'] }} transition={{ duration:3, repeat:Infinity }}
          className="w-8 h-8 rounded-xl gradient-brand flex items-center justify-center text-sm">⚡</motion.div>
        <div>
          <div className="font-display font-bold text-sm text-slate-100 leading-tight">OFPPT AI</div>
          <div className="text-[9px] text-slate-500 leading-tight">GE & GEn</div>
        </div>
      </div>

      <motion.button whileHover={{ scale:1.05 }} whileTap={{ scale:0.95 }}
        onClick={toggleSidebar} aria-label="القائمة"
        className={cn('w-9 h-9 flex flex-col items-center justify-center rounded-xl border transition-all',
          sidebarOpen ? 'bg-primary/10 border-primary/30' : 'bg-white/[0.03] border-white/[0.05] hover:border-primary/20'
        )}>
        <AnimatePresence mode="wait">
          {sidebarOpen
            ? <motion.div key="x"  initial={{rotate:-90,opacity:0}} animate={{rotate:0,opacity:1}} exit={{rotate:90,opacity:0}} transition={{duration:0.12}}><X size={15} className="text-primary"/></motion.div>
            : <motion.div key="mn" initial={{rotate:90,opacity:0}}  animate={{rotate:0,opacity:1}} exit={{rotate:-90,opacity:0}} transition={{duration:0.12}}><Menu size={15} className="text-slate-300"/></motion.div>
          }
        </AnimatePresence>
      </motion.button>
    </header>
  )
}

// ── Sidebar ─────────────────────────────────────────────────
function Sidebar() {
  const { sidebarOpen, closeSidebar, specialty } = useUIStore()
  const { xp, level, streak } = useGamStore()
  const { apiKey } = useAIStore()
  const location   = useNavigate()
  const loc        = useLocation()

  useEffect(() => { closeSidebar() }, [loc.pathname, closeSidebar])

  const navigate = useNavigate()

  return (
    <>
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[1099]"
            onClick={closeSidebar} />
        )}
      </AnimatePresence>

      <motion.aside
        initial={false}
        animate={{ x: sidebarOpen ? '0%' : '100%' }}
        transition={{ type:'spring', stiffness:320, damping:38 }}
        className="fixed top-0 right-0 h-full w-[min(280px,88vw)] bg-elevated border-l border-white/[0.05] z-[1100] flex flex-col shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3.5 border-b border-white/[0.05] safe-top">
          <span className="font-display font-bold text-sm text-slate-100">⚡ OFPPT</span>
          <button onClick={closeSidebar} className="w-7 h-7 flex items-center justify-center bg-white/[0.04] border border-white/[0.05] rounded-lg text-slate-400 hover:text-slate-200 transition-colors text-xs">✕</button>
        </div>

        {/* Profile */}
        <div className="mx-3 mt-3 p-3.5 bg-white/[0.03] border border-white/[0.05] rounded-xl">
          <div className="flex items-center gap-3 mb-2.5">
            <div className="w-9 h-9 rounded-xl gradient-brand flex items-center justify-center text-base">🎓</div>
            <div>
              <div className="text-sm font-semibold text-slate-100">طالب OFPPT</div>
              <div className="text-xs text-slate-400">{specialty === 'GE' ? 'هندسة كهربائية' : 'هندسة الطاقة'}</div>
            </div>
          </div>
          <div className="flex justify-between text-xs text-slate-400 mb-1"><span>المستوى {level}</span><span>{xp} XP</span></div>
          <div className="h-1.5 bg-white/[0.06] rounded-full overflow-hidden">
            <motion.div animate={{width:`${Math.min(100,(xp/(level*100))*100)}%`}} transition={{duration:0.6}} className="h-full bg-gradient-to-r from-blue-700 to-primary rounded-full" />
          </div>
          {!apiKey && (
            <div className="mt-2 text-[10px] text-amber-400/80 bg-amber-400/5 border border-amber-400/10 rounded-lg px-2 py-1">
              ⚠️ أضف مفتاح Gemini المجاني في الإعدادات
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto no-scrollbar px-3 pb-4 mt-3 space-y-3">
          {SIDEBAR_NAV.map(({ section, items }) => (
            <div key={section}>
              <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-2 mb-1.5">{section}</p>
              <div className="space-y-0.5">
                {items.map(item => {
                  const active = loc.pathname === item.path
                  return (
                    <motion.button key={item.path} whileHover={{x:-2}} whileTap={{scale:0.98}}
                      onClick={() => navigate(item.path)}
                      className={cn('w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-right transition-all',
                        active ? 'bg-primary/10 border border-primary/20 text-slate-100' : 'hover:bg-white/[0.03] text-slate-400 hover:text-slate-200'
                      )}>
                      <div className={cn('w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 transition-colors',
                        active ? 'bg-primary/20 text-primary' : 'bg-white/[0.04] border border-white/[0.04] text-slate-500')}>
                        <item.icon size={13} />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-semibold leading-tight truncate">{item.label}</div>
                        <div className="text-[9px] text-slate-500 truncate">{item.sub}</div>
                      </div>
                      {active && <div className="mr-auto w-1 h-5 bg-primary rounded-full" />}
                    </motion.button>
                  )
                })}
              </div>
            </div>
          ))}
        </nav>
      </motion.aside>
    </>
  )
}

// ── Bottom Navigation ──────────────────────────────────────
function BottomNav() {
  const loc      = useLocation()
  const navigate = useNavigate()
  const hidden   = ['/login', '/register'].some(r => loc.pathname.startsWith(r))
  if (hidden) return null

  return (
    <nav className="fixed bottom-0 inset-x-0 z-[999] glass border-t border-white/[0.05] safe-bottom">
      <div className="flex items-center justify-around px-2 pt-2 pb-1">
        {NAV.map(tab => {
          const active = loc.pathname === tab.path
          return (
            <motion.button key={tab.path} whileTap={{scale:0.88}}
              onClick={() => navigate(tab.path)}
              className="flex flex-col items-center gap-0.5 px-3 py-1 rounded-xl relative"
            >
              {active && (
                <motion.div layoutId="bottom-pill"
                  className="absolute inset-0 bg-primary/10 border border-primary/20 rounded-xl"
                  transition={{type:'spring',stiffness:400,damping:32}} />
              )}
              <tab.icon size={17} className={cn('relative z-10 transition-colors', active ? 'text-primary' : 'text-slate-500')} />
              <span className={cn('relative z-10 text-[9px] font-medium transition-colors', active ? 'text-primary' : 'text-slate-500')}>
                {tab.label}
              </span>
            </motion.button>
          )
        })}
      </div>
    </nav>
  )
}

// ── AppLayout ──────────────────────────────────────────────
export function AppLayout({ children }: { children: React.ReactNode }) {
  const { setOnline, toast } = useUIStore()

  useEffect(() => {
    const on  = () => { setOnline(true);  toast('✅ تم استعادة الاتصال', 'success') }
    const off = () => { setOnline(false); toast('⚠️ لا يوجد اتصال بالإنترنت', 'warning') }
    window.addEventListener('online',  on)
    window.addEventListener('offline', off)
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off) }
  }, [setOnline, toast])

  return (
    <div className="min-h-screen bg-base">
      <Header />
      <Sidebar />
      <main className="pt-[56px] pb-[64px] min-h-screen">
        {children}
      </main>
      <BottomNav />
      <PWAInstallBanner />
      <OfflineIndicator />
    </div>
  )
}
