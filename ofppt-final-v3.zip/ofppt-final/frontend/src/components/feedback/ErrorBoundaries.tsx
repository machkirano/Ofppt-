import React, { Component, lazy, Suspense } from 'react'
import { useRouteError, isRouteErrorResponse, Link } from 'react-router-dom'
import { motion } from 'framer-motion'

// ═══════════════════════════════════════════════════════════
// ERROR BOUNDARIES — Global, API, Route
// ═══════════════════════════════════════════════════════════

interface EBState { hasError: boolean; error: Error | null; errorId: string }

// ── Global Error Boundary ──────────────────────────────────
export class GlobalErrorBoundary extends Component<
  { children: React.ReactNode; fallback?: React.ReactNode },
  EBState
> {
  state: EBState = { hasError: false, error: null, errorId: '' }

  static getDerivedStateFromError(error: Error): EBState {
    return { hasError: true, error, errorId: `err_${Date.now()}` }
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('[GlobalEB]', error, info)
    // Report to free error tracking (Sentry free tier / console)
    this.reportError(error, info)
  }

  private reportError(error: Error, info: React.ErrorInfo) {
    try {
      const payload = {
        message:   error.message,
        stack:     error.stack?.slice(0, 500),
        component: info.componentStack?.slice(0, 200),
        url:       window.location.href,
        timestamp: new Date().toISOString(),
      }
      // Store locally for debugging
      const errors = JSON.parse(localStorage.getItem('ofppt_errors') ?? '[]')
      errors.push(payload)
      localStorage.setItem('ofppt_errors', JSON.stringify(errors.slice(-10)))
    } catch { /* ignore */ }
  }

  render() {
    if (!this.state.hasError) return this.props.children
    if (this.props.fallback)   return this.props.fallback

    return (
      <div className="min-h-screen bg-base flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-elevated border border-white/5 rounded-2xl p-8 text-center"
        >
          <div className="text-4xl mb-4">⚡</div>
          <h2 className="font-display font-bold text-xl text-slate-100 mb-2">
            حدث خطأ غير متوقع
          </h2>
          <p className="text-slate-400 text-sm mb-6 leading-relaxed">
            {this.state.error?.message ?? 'خطأ غير معروف'}
          </p>
          <div className="flex gap-3 justify-center">
            <button
              onClick={() => { this.setState({ hasError: false, error: null, errorId: '' }); window.location.href = '/' }}
              className="px-4 py-2 gradient-brand text-white rounded-xl text-sm font-semibold"
            >
              العودة للرئيسية
            </button>
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-white/[0.05] border border-white/5 text-slate-300 rounded-xl text-sm"
            >
              إعادة تحميل
            </button>
          </div>
          {import.meta.env.DEV && (
            <details className="mt-4 text-left text-xs text-slate-500 bg-black/20 rounded-lg p-3">
              <summary className="cursor-pointer mb-2">تفاصيل الخطأ (DEV)</summary>
              <pre className="whitespace-pre-wrap break-all">{this.state.error?.stack}</pre>
            </details>
          )}
        </motion.div>
      </div>
    )
  }
}

// ── Route Error Boundary (React Router v6) ─────────────────
export function RouteErrorBoundary() {
  const error = useRouteError()

  const status  = isRouteErrorResponse(error) ? error.status  : 500
  const message = isRouteErrorResponse(error) ? error.statusText : 'خطأ داخلي'

  const configs: Record<number, { emoji: string; title: string; desc: string }> = {
    404: { emoji: '🔌', title: 'الصفحة غير موجودة', desc: 'تحقق من الرابط أو ارجع للرئيسية' },
    403: { emoji: '🔒', title: 'غير مصرح',          desc: 'ليس لديك صلاحية للوصول لهذه الصفحة' },
    500: { emoji: '⚡', title: 'خطأ في الخادم',     desc: 'حدث خطأ — يُرجى المحاولة لاحقاً' },
  }

  const cfg = configs[status] ?? configs[500]

  return (
    <div className="min-h-screen bg-base flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-sm w-full text-center"
      >
        <div className="text-5xl mb-5">{cfg.emoji}</div>
        <div className="text-slate-500 text-sm font-mono mb-2">{status}</div>
        <h1 className="font-display font-bold text-xl text-slate-100 mb-3">{cfg.title}</h1>
        <p className="text-slate-400 text-sm mb-6">{cfg.desc}</p>
        <Link to="/" className="inline-flex items-center gap-2 px-5 py-2.5 gradient-brand text-white rounded-xl text-sm font-semibold">
          ← الرئيسية
        </Link>
      </motion.div>
    </div>
  )
}

// ── API Error Boundary (for data-fetching components) ──────
interface APIErrorBoundaryProps {
  children:   React.ReactNode
  fallback?:  (retry: () => void) => React.ReactNode
}

interface APIEBState { hasError: boolean; retryCount: number }

export class APIErrorBoundary extends Component<APIErrorBoundaryProps, APIEBState> {
  state: APIEBState = { hasError: false, retryCount: 0 }

  static getDerivedStateFromError(): APIEBState { return { hasError: true, retryCount: 0 } }

  retry = () => this.setState(s => ({ hasError: false, retryCount: s.retryCount + 1 }))

  render() {
    if (!this.state.hasError) return this.props.children
    if (this.props.fallback)  return this.props.fallback(this.retry)

    return (
      <div className="flex flex-col items-center gap-3 py-8 text-center">
        <span className="text-2xl">📡</span>
        <p className="text-sm text-slate-400">فشل تحميل البيانات</p>
        <button
          onClick={this.retry}
          className="text-xs px-3 py-1.5 bg-white/[0.04] border border-white/5 rounded-lg text-primary hover:border-primary/30 transition-colors"
        >
          إعادة المحاولة
        </button>
      </div>
    )
  }
}

// ── Suspense wrapper with skeleton ────────────────────────
export function PageSuspense({ children }: { children: React.ReactNode }) {
  return (
    <Suspense fallback={<PageSkeleton />}>
      {children}
    </Suspense>
  )
}

function PageSkeleton() {
  return (
    <div className="px-4 py-6 max-w-lg mx-auto space-y-4 animate-pulse">
      <div className="skeleton h-7 w-40 rounded-xl" />
      <div className="skeleton h-4 w-64 rounded-lg" />
      {[1,2,3].map(i => (
        <div key={i} className="skeleton h-20 rounded-2xl" />
      ))}
    </div>
  )
}
