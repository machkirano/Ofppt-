import React from 'react'
import ReactDOM from 'react-dom/client'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { AppRouter } from '@/router'
import { ToastContainer } from '@components/ui/Toast'
import { PWAUpdateBanner } from '@pwa/PWAManager'
import { useUIStore } from '@store/index'
import { reportWebVitals } from '@utils/vitals'
import '@/styles/globals.css'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime:           2 * 60 * 1000,
      gcTime:              5 * 60 * 1000,
      retry:               2,
      refetchOnWindowFocus:false,
    },
  },
})

function Providers({ children }: { children: React.ReactNode }) {
  return (
    <QueryClientProvider client={queryClient}>
      {children}
    </QueryClientProvider>
  )
}

function ToastBridge() {
  const { toasts, removeToast } = useUIStore()
  return <ToastContainer toasts={toasts} onRemove={removeToast} />
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <Providers>
      <AppRouter />
      <ToastBridge />
      <PWAUpdateBanner />
    </Providers>
  </React.StrictMode>
)

// Web Vitals reporting (free — logs to console in dev, analytics in prod)
reportWebVitals()
