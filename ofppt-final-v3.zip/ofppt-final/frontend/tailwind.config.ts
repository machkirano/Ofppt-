// tailwind.config.ts
import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        display: ['Syne', 'sans-serif'],
        body:    ['IBM Plex Sans Arabic', 'system-ui', 'sans-serif'],
        mono:    ['JetBrains Mono', 'monospace'],
      },
      colors: {
        base:      '#060A12',
        elevated:  '#0D1117',
        raised:    '#131B2E',
        overlay:   '#1A2540',
        primary:   '#3B82F6',
        secondary: '#8B5CF6',
        accent:    '#06FFA5',
      },
      animation: {
        'fade-up':  'fadeUp 0.4s cubic-bezier(0.16,1,0.3,1) both',
        'msg-in':   'msgIn 0.24s cubic-bezier(0.16,1,0.3,1) both',
        'glow':     'glow 2s ease-in-out infinite',
        'record':   'recordPulse 1s ease-in-out infinite',
      },
      keyframes: {
        fadeUp:      { from: { opacity:'0', transform:'translateY(16px)' }, to: { opacity:'1', transform:'translateY(0)' } },
        msgIn:       { from: { opacity:'0', transform:'translateY(8px)'  }, to: { opacity:'1', transform:'translateY(0)' } },
        glow:        { '0%,100%': { boxShadow:'0 0 20px rgba(59,130,246,0.3)' }, '50%': { boxShadow:'0 0 40px rgba(59,130,246,0.6)' } },
        recordPulse: { '0%,100%': { boxShadow:'0 0 0 0 rgba(244,63,94,0)' }, '50%': { boxShadow:'0 0 0 8px rgba(244,63,94,0.15)' } },
      },
      transitionTimingFunction: {
        spring: 'cubic-bezier(0.34,1.56,0.64,1)',
        out:    'cubic-bezier(0.16,1,0.3,1)',
      },
    },
  },
  plugins: [],
}

export default config
